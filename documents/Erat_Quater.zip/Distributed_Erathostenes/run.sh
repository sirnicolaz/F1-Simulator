POLYORB_DSA_NAME_SERVICE="$(cat ./ior.txt)"
export POLYORB_DSA_NAME_SERVICE
./obj/main
