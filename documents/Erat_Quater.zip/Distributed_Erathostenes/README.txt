L'applicazione distribuita qui allegata va compilata con po_gnatdist, 
il compilatore del Distributed Annex di Ada realizzato all'interno di PolyORB.
PolyORB va scaricato dal sito indicato nella pagina del corso. 

- Compilare con po_gnatdist (by default po_gnatdist will use the Ada starter)
- Specificare un name server per l'applicazione (for example the one included 
  in PolyORB: po_cos_naming)
- Assegnare alla variabile d'ambiente POLYORB_DSA_NAME_SERVICE lo IOR URI che 
  riferisce il name server; esportare la variabile.
